﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;

using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KeyBoard_Trainer
{
	/// <summary>
	/// Логика взаимодействия для Auth.xaml
	/// </summary>
	public partial class Auth : Window
	{
		List<UsersInfo> all_users;
		MainWindow trainer;
		DlgBoxWindow dlgBox;
		public Auth()
		{
			all_users = new List<UsersInfo>();
			LoadUsers();
			InitializeComponent();
			txbloggin.Text = GetLastRemember();

		}


		string GetLastRemember()
		{
			if (all_users.Count == 0) return string.Empty;
			UsersInfo b = all_users.FindLast(s => s.Remember == true);
			if (b != null)
			{
				chkbaxremember.IsChecked = true;
				return b.Login;
			}
			else return string.Empty;
		}

		void LoadUsers()
		{
			if (!File.Exists(Environment.CurrentDirectory + @"\Settings\accounts.bin"))
			{
				return;
			}
			var str = new FileStream(Environment.CurrentDirectory + @"\Settings\accounts.bin", FileMode.Open, FileAccess.Read);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			all_users = binaryFormatter.Deserialize(str) as List<UsersInfo>;
			str.Close();
		}


		private void btnregister_Click(object sender, RoutedEventArgs e)
		{
			FileStream str = null;
			try
			{
				if (boxpswd.Password.Length < 5)
				{

					dlgBox = new DlgBoxWindow("Lenght field must be more 5");
					dlgBox.ShowDialog();
					return;
				}
				if (txbloggin.Text.Length > 0)
				{
					UsersInfo s2 = all_users.Find(s3 => s3.Login == txbloggin.Text);
					if (s2 != null)
					{

						dlgBox = new DlgBoxWindow("This login already exist");
						dlgBox.ShowDialog();
						return;
					}
					all_users.Add(new UsersInfo(txbloggin.Text, boxpswd.Password, chkbaxremember.IsChecked == true ? true : false));
					if (!Directory.Exists(Environment.CurrentDirectory + @"\Settings\"))
					{
						Directory.CreateDirectory(Environment.CurrentDirectory + @"\Settings\");
					}
					str = new FileStream(Environment.CurrentDirectory + @"\Settings\accounts.bin", FileMode.Create, FileAccess.Write);
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					binaryFormatter.Serialize(str, all_users);
					str.Close();
					dlgBox = new DlgBoxWindow("Done");
					dlgBox.ShowDialog();

				}
				else
				{
					dlgBox = new DlgBoxWindow("Fill all fields");
					dlgBox.ShowDialog();
				}

		}
			catch (Exception ex)
			{
				System.Windows.Forms.MessageBox.Show(ex.Message + ex.StackTrace);
			}
			finally
			{
				if (str != null) str.Close();
			}
		}
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			if (txbloggin.Text.Length > 0)
			{
				boxpswd.Focus();
			}
			else
				txbloggin.Focus();
		}

		private void btnlogin_Click(object sender, RoutedEventArgs e)
		{
			FileStream str = null;
			try
			{

				if (all_users.Count == 0)
				{

					dlgBox = new DlgBoxWindow("Cant find this user");
					dlgBox.ShowDialog();
				}
				else
				{
					if (showpass.IsChecked == true)
					{
						boxpswd.Password = txbpassword.Text;
					}
					UsersInfo b = all_users.Find(s => s.Login == txbloggin.Text && s.Password == boxpswd.Password);
					if (b != null)
					{

						b.Remember = chkbaxremember.IsChecked == true ? true : false;
						//перезаписываю пользователей на случай когда было изменено состояние пользователя

						if (b.Remember)
						{
							//перезаписываю текущего пользователя, как последнего вошедшего, чтобы подтягивать корректно данные из базы пользователей для ремемберми
							all_users.Remove(b);
							all_users.Add(b);
						}
						if (!Directory.Exists(Environment.CurrentDirectory + @"\Settings\"))
						{
							Directory.CreateDirectory(Environment.CurrentDirectory + @"\Settings\");
						}

						this.Hide();
						int tmp_stat = b.Statistics.Count;
						int cur_them = b.My_themes;
						trainer = new MainWindow(b);
						trainer.Title = trainer.Title + " | User: " + b.Login;
						trainer.ShowDialog();
						//if was some changes we rewrites all info
						str = new FileStream(Environment.CurrentDirectory + @"\Settings\accounts.bin", FileMode.Create, FileAccess.Write);
						BinaryFormatter binaryFormatter = new BinaryFormatter();
						binaryFormatter.Serialize(str, all_users);
						str.Close();
						txbpassword.Text = string.Empty;
						boxpswd.Password = string.Empty;
						this.ShowDialog();

					}
					else
					{

						//System.Windows.Forms.MessageBox.Show("Incorrect login/password", "Login", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning, System.Windows.Forms.MessageBoxDefaultButton.Button1);
						dlgBox = new DlgBoxWindow("Incorrect login/password");
						dlgBox.ShowDialog();
					}
				}
			}
			catch (Exception ex)
			{
				System.Windows.Forms.MessageBox.Show(ex.Message + ex.StackTrace);
			}
			finally
			{
				if (str != null) str.Close();
			}
		}

		private void showpass_Checked(object sender, RoutedEventArgs e)
		{
			txbpassword.Text = boxpswd.Password;
			boxpswd.Visibility = Visibility.Hidden;

		}

		private void showpass_Unchecked(object sender, RoutedEventArgs e)
		{
			boxpswd.Password = txbpassword.Text;
			boxpswd.Visibility = Visibility.Visible;
		}

		private void boxpswd_GotFocus(object sender, RoutedEventArgs e)
		{
			if (boxpswd.Password.Length > 0) boxpswd.SelectAll();
		}

		private void boxpswd_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Enter)
			{

				btnlogin_Click(null, null);
			}
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			dlgBox = new DlgBoxWindow("You realy want to exit?");
			Button button = new Button();
			button.Content = "No";
			button.Style = dlgBox.btnok.Style;
			button.Click += Button_Click_Cancel_DlgBox;
			dlgBox.wrap.Children.Add(button);
			if (dlgBox.ShowDialog() != true)
			{
				e.Cancel = true;
			}
		}

		private void Button_Click_Cancel_DlgBox(object sender, RoutedEventArgs e)
		{
			if (dlgBox != null) dlgBox.Close();
		}

		private void Window_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Escape) this.Close();
		}

		private void btnexit_Click(object sender, RoutedEventArgs e)
		{
			this.Close();

		}


	}
}
