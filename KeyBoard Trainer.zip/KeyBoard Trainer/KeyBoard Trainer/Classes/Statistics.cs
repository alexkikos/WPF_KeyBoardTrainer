﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBoard_Trainer.Classes
{
	[Serializable]
	public class Statistics
	{
		TimeSpan elapsedtime;
		DateTime time_when_end;
		int speed;
		int errors;
		int difficulty;
		bool case_sensitive;
		string lagnues;

		public Statistics(TimeSpan elapsedtime, DateTime time_when_end, int speed, int errors, int difficulty, bool sensitive,string lang)
		{
			lagnues = lang;
			this.elapsedtime = elapsedtime;
			this.time_when_end = time_when_end;
			this.speed = speed;
			this.difficulty = difficulty;
			this.case_sensitive = sensitive;
			this.errors = errors;
		}
		public Statistics()
		{
			lagnues = "en";
			case_sensitive = true;
			difficulty = 1;
			this.elapsedtime = TimeSpan.Zero;
			this.time_when_end = DateTime.Now;
			this.speed = 0;
			this.errors = 0;
		}
		public TimeSpan Elapsedtime { get => elapsedtime; set => elapsedtime = value; }
		public DateTime Time_when_end { get => time_when_end; set => time_when_end = value; }
		public int Speed { get => speed; set => speed = value; }
		public int Errors { get => errors; set => errors = value; }
		public bool Case_sensitive { get => case_sensitive; set => case_sensitive = value; }
		public int Difficulty { get => difficulty; set => difficulty = value; }
		public string Lagnues { get => lagnues; set => lagnues = value; }

		public  bool Equals(Statistics obj)
		{
			return
					elapsedtime == obj.elapsedtime &&
				   time_when_end == obj.time_when_end &&
				   speed == obj.speed &&
				   errors == obj.errors &&
			difficulty == obj.difficulty &&
			case_sensitive == obj.case_sensitive;
		}
	}
}
