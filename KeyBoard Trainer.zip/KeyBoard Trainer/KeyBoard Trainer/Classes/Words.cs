﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace KeyBoard_Trainer
{
	[Serializable]
	public class Words : INotifyPropertyChanged, ISerializable
	{

		List<string> difficulty_1;
		List<string> difficulty_2;
		int errors;
		int correct;


		[NonSerialized]
		Timer timer;
		TimeSpan timeSpan;	
		DateTime start;	
		DateTime end;
		static int total_obj = 0;
		string last_char;

		public void IniFields()
		{
			this.last_char = "";
			Errors = 0;
			timeSpan = TimeSpan.Zero;
			timer = new Timer();
			timer.Interval = 1000;
			timer.Elapsed += Timer_Elapsed;
		}

		public Words()
		{
			IniFields();
			Difficulty_1 = new List<string>();
			Difficulty_2 = new List<string>();
			Difficulty_1.Add("No more champagne And the fireworks are through Here we are");
			difficulty_1.Add("me and you Feeling lost and feeling blue.");
			difficulty_1.Add("It's the end of the party And the morning seems so grey");
			difficulty_1.Add("So unlike yesterday Now's the time for us to say..");
			Difficulty_1.Add("Happy new year Happy new year May we all have");
			difficulty_1.Add("is a friend Happy new year Happy new year May we all have our hopes,");
			difficulty_1.Add(" our will to try If we don't we might as well lay down and die");
			Difficulty_1.Add("Sometimes I see How the brave new world arrives");
			difficulty_1.Add("man is a fool And he thinks he'll be okay Dragging on,");
			difficulty_1.Add(" feet of clay Never knowing he's astray Keeps on going anyway...");
			difficulty_1.Add("Happy new year Happy new year May we all have a vision");
			difficulty_1.Add("now and then Of a world where every neighbour is a friend");
			difficulty_1.Add("Happy new year Happy new year May we all have our hopes, our will");
			difficulty_1.Add("a vision now and then Of a world where every neighbour");
			difficulty_1.Add("to try If we don't we might as well lay down and die You and I");
			difficulty_1.Add("Seems to me now That the dreams we had before Are all dead, nothing more");
			difficulty_1.Add("And I see how it thrives In the ashes of our lives Oh yes");

			Difficulty_2.Add("She WaS More lIke a bEauTy quEEn FROM a movie scene I said, don't Mind");
			difficulty_2.Add("But whAt do you mEan I am the one WhO will dance on tHe");
			difficulty_2.Add("floor in the rOund She  sAid I Am thE");
			difficulty_2.Add("one who will dance On the floor in the round");
			Difficulty_2.Add("She WaS More lIke a bEauTy quEEn FROM a movie scene");
			difficulty_2.Add("I said, don't Mind But whAt do you mEan");
			Difficulty_2.Add("I am the one WhO will dance on tHe    floor in the rOund She");
			difficulty_2.Add("sAid I Am thE  one who will dance On the floor in the round");
			difficulty_2.Add("Hood Of my cAr Radio's, Just loud enough so I can hear LevOn");
			difficulty_2.Add("Where yOu are is anybody's gUEss but mIne JuSt a soNg that we");
			difficulty_2.Add("grEw up on ConsTellAtions sEem so ouTta");
			difficulty_2.Add("line But I'm wishIng we coUld makE it tHis timE");
			difficulty_2.Add("far 'cause I can see me on a spaceship lEavIng");
			difficulty_2.Add("here only to find that we're nOt the only onEs");
			difficulty_2.Add("If someboDy's out there Show me that you care");
			difficulty_2.Add("Give me a sIgn thAt COMES outta nowheRe");
			difficulty_2.Add("Like a shoOting star Or Maybe lIfe on Mars SometHing inSide tElls me we can't be tOo");
			difficulty_2.Add("If sOmeBody's out tHEre Show me that");
			difficulty_2.Add("yOu care Give Me a sign tHat cOmes outta noWhere only ones");
			difficulty_2.Add("Like a shOoting star can see me on a spacesHip leaving herE only to find that we're not the");
		}


		public void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("errors", errors);
			info.AddValue("correct", correct);
			info.AddValue("dif1", difficulty_1, typeof(List<string>));
			info.AddValue("dif2", difficulty_2, typeof(List<string>));		
		}

		Words(SerializationInfo info, StreamingContext context)
		{
			errors = info.GetInt32("errors");
			correct = info.GetInt32("correct");
			difficulty_1 = new List<string>();
			difficulty_2 = new List<string>();
			difficulty_1 = info.GetValue("dif1", typeof(List<string>)) as List<string>;
			difficulty_2 = info.GetValue("dif2", typeof(List<string>)) as List<string>;
		}

		private void Timer_Elapsed(object sender, ElapsedEventArgs e)
		{
			TimeSpan = DateTime.Now - start;
		}



		public string Last_char
		{
			get => last_char;
			set
			{
				if (value != last_char)
				{
					last_char = value;
					PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Last_char)));
				}
			}
		}

		public List<string> Difficulty_1 { get => difficulty_1; internal set => difficulty_1 = value; }
		public List<string> Difficulty_2 { get => difficulty_2; internal set => difficulty_2 = value; }
		public TimeSpan TimeSpan
		{
			get
			{
				if (start.Year < DateTime.Now.Year)
				{
					return timeSpan;
				}
				else
				{
					timeSpan = DateTime.Now - Start;

					return timeSpan;
				}
			}
			set
			{
				if (value != timeSpan)
				{
					timeSpan = value;
					PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimeSpan)));
				}
			}
		}
		public DateTime Start { get => start; set => start = value; }
		public DateTime End { get => end; set => end = value; }
		public int Errors { get => errors; set { errors = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Errors))); } }


		public int Correct { get => correct; set { correct = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Correct))); } }
		public Timer Timer { get => timer; set => timer = value; }


		public event PropertyChangedEventHandler PropertyChanged;
	}



}
