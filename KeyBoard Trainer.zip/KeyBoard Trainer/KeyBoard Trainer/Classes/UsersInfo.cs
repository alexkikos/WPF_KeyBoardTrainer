﻿using KeyBoard_Trainer.Classes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBoard_Trainer
{
	[Serializable]
	public class UsersInfo
	{

		string login;
		string password;
		bool remember;
		List<Statistics> statistics;
		int my_themes;

		public UsersInfo()
		{
			statistics = new List<Statistics>();
			remember = false;
			login = string.Empty;
			password = string.Empty;
			my_themes = 0;
		}

		public UsersInfo(string login, string password, bool remember, int themes=0)
		{
			statistics = new List<Statistics>();
			this.remember = remember;
			this.login = login;
			this.password = password;
			my_themes = themes;
		}

		public string Login { get => login; set => login = value; }
		public string Password { get => password;  }
		public bool Remember { get => remember; set => remember = value; }
		public int My_themes { get => my_themes; set => my_themes = value; }
		public List<Statistics> Statistics
		{
			get => statistics;
			set
			{
				if (value != statistics)
				{
					statistics = value;					

				}
			}
		}



	

		public  bool Equals(UsersInfo obj)
		{ 
			return 
				   login == obj.login &&
				   password == obj.password;
		}
	}
}
