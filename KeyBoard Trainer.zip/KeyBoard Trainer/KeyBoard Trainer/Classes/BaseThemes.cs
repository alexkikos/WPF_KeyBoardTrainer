﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBoard_Trainer
{
	[Serializable]
	class  BaseThemes
	{

		List<Themes> themes;
		public BaseThemes()
		{
			themes = new List<Themes>();
			themes.Add(new Themes("standard"));
			themes.Add(new Themes("modify"));
		}

		public List<Themes> GetThemes()
		{
			return themes;
		}

	}
}
