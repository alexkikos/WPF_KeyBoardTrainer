﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyBoard_Trainer
{
	[Serializable]
	public class Themes
	{
		string name;


		public Themes()
		{
			name = "";
		}
		public Themes(string name_theme)
		{
			name = name_theme;
		}
		public string Name { get => name;  }

	}
}
