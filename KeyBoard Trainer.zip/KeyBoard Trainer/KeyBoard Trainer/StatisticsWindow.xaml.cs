﻿using KeyBoard_Trainer.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KeyBoard_Trainer
{
	/// <summary>
	/// Логика взаимодействия для Statistics.xaml
	/// </summary>
	public partial class StatisticsWindow : Window
	{
		UsersInfo tmp;


		public StatisticsWindow()
		{
			InitializeComponent();
		}

		
		public StatisticsWindow(UsersInfo user)
		{
			tmp = user;
			
			InitializeComponent();
			lstview.ItemsSource = tmp.Statistics;
		}

		private void btndel_Click(object sender, RoutedEventArgs e)
		{
			if (lstview.SelectedValue != null)
			{
				foreach (Statistics item in lstview.SelectedItems)
				{
					tmp.Statistics.Remove(item);			

				}
				lstview.ItemsSource = null;
				lstview.ItemsSource = tmp.Statistics;
			}
		}

		private void btnclearall_Click(object sender, RoutedEventArgs e)
		{
			if (lstview.Items.Count > 0)
			{
				tmp.Statistics.Clear();
				lstview.ItemsSource = null;
				lstview.ItemsSource = tmp.Statistics;
			}
		}
	}
}
