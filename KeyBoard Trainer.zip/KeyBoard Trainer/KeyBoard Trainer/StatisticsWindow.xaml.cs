﻿using KeyBoard_Trainer.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KeyBoard_Trainer
{
	/// <summary>
	/// Логика взаимодействия для Statistics.xaml
	/// </summary>
	public partial class StatisticsWindow : Window
	{
		UsersInfo tmp;
		List<string> dif;
		bool start = false;
		public StatisticsWindow()
		{
			InitializeComponent();
		}

		
		public StatisticsWindow(UsersInfo user)
		{
			tmp = user;		
			dif = new List<string>();
			this.DataContext = tmp;
			dif.Add("Easy");
			dif.Add("Hard");	
			InitializeComponent();
			cmb_dif.ItemsSource = dif;			
			cmb_dif.SelectionChanged += Cmb_dif_SelectionChanged;
			cmb_dif_add.ItemsSource = dif;
			start = true;

		}

		private void Cmb_dif_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ComboBox g = sender as ComboBox;
			if (g.SelectedIndex == 0)
			{
				cmb_sent.ItemsSource = tmp.Words.Difficulty_1;
			}
			else 
				cmb_sent.ItemsSource = tmp.Words.Difficulty_2;
		}

		private void btndel_Click(object sender, RoutedEventArgs e)
		{
			if (lstview.SelectedValue != null)
			{
				foreach (Statistics item in lstview.SelectedItems)
				{
					tmp.Statistics.Remove(item);			

				}
				lstview.ItemsSource = null;
				lstview.ItemsSource = tmp.Statistics;
			}
		}

		private void btnclearall_Click(object sender, RoutedEventArgs e)
		{
			if (lstview.Items.Count > 0)
			{
				tmp.Statistics.Clear();
				lstview.ItemsSource = null;
				lstview.ItemsSource = tmp.Statistics;
			}
		}

		
		private void chk_box_edits_items_Checked(object sender, RoutedEventArgs e)
		{
			if (!start) return;
			cmb_dif.IsEnabled = true;
			cmb_sent.IsEnabled = true;
			txb_setntnce_edit.IsEnabled = true;
			btn_save.IsEnabled = true;
		}

		private void chk_box_edits_items_Unchecked(object sender, RoutedEventArgs e)
		{
			if (!start) return;
			cmb_dif.IsEnabled = false;
			cmb_sent.IsEnabled = false;
			txb_setntnce_edit.IsEnabled = false;
			btn_save.IsEnabled = false;
		}

		private void btn_save_Click(object sender, RoutedEventArgs e)
		{
			if (txb_setntnce_edit.Text.Length > 0)
			{
				if (txb_setntnce_edit.Text == cmb_sent.SelectedItem.ToString()) return;
				if (cmb_dif.SelectedIndex == 0)
				{
					tmp.Words.Difficulty_1.Remove(cmb_sent.SelectedItem.ToString());
					tmp.Words.Difficulty_1.Insert(0, txb_setntnce_edit.Text);
					cmb_sent.ItemsSource = null;
					cmb_sent.ItemsSource = tmp.Words.Difficulty_1;
				}
				else
				{
					tmp.Words.Difficulty_2.Remove(cmb_sent.SelectedItem.ToString());
					tmp.Words.Difficulty_2.Insert(0, txb_setntnce_edit.Text);
					cmb_sent.ItemsSource = null;
					cmb_sent.ItemsSource = tmp.Words.Difficulty_2;
				}
			}
		}


		private void cmb_sent_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (cmb_sent.SelectedItem == null) return;
		
			txb_setntnce_edit.Text = cmb_sent.SelectedItem.ToString();
		}

		private void chk_box_add_items_Checked(object sender, RoutedEventArgs e)
		{
			if (!start) return;
			cmb_dif_add.IsEnabled = true;
			txb_setntnce_add.IsEnabled = true;
			btn_add.IsEnabled = true;
		}

		private void chk_box_add_items_Unchecked(object sender, RoutedEventArgs e)
		{
			if (!start) return;
			cmb_dif_add.IsEnabled = false;
			txb_setntnce_add.IsEnabled = false;
			btn_add.IsEnabled = false;

		}

		private void btn_add_Click(object sender, RoutedEventArgs e)
		{
			if (txb_setntnce_add.Text.Length == 0) return;
			if (cmb_dif_add.SelectedItem == null) return;
			if (cmb_dif_add.SelectedIndex == 0)
			{
				tmp.Words.Difficulty_1.Add(txb_setntnce_add.Text);
				cmb_sent.ItemsSource = null;
				cmb_sent.ItemsSource = tmp.Words.Difficulty_1;
			}
			else
			{
				tmp.Words.Difficulty_2.Add(txb_setntnce_add.Text);
				cmb_sent.ItemsSource = null;
				cmb_sent.ItemsSource = tmp.Words.Difficulty_2;
			}
			DlgBoxWindow dlgBoxWindow = new DlgBoxWindow("Done");
			dlgBoxWindow.ShowDialog();
		}


		string remove = string.Empty;
		private void MenuItem_Click(object sender, RoutedEventArgs e)
		{
			
			if (string.IsNullOrEmpty(remove)) return;
			
			if (cmb_dif_add.SelectedIndex == 0)
			{
				tmp.Words.Difficulty_1.Remove(remove);
				cmb_sent.ItemsSource = null;
				cmb_sent.ItemsSource = tmp.Words.Difficulty_1;
			}
			else
			{
				tmp.Words.Difficulty_2.Remove(remove);
				cmb_sent.ItemsSource = null;
				cmb_sent.ItemsSource = tmp.Words.Difficulty_2;
			}
			DlgBoxWindow dlgBoxWindow = new DlgBoxWindow("Done");
			dlgBoxWindow.ShowDialog();
			remove = string.Empty;
		}

	

		private void ComboBoxItem_MouseEnter(object sender, MouseEventArgs e)
		{
			ComboBoxItem g = sender as ComboBoxItem;
			remove = g.DataContext.ToString();
		}

	
	}
}
