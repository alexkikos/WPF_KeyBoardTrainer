﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace KeyBoard_Trainer
{


	public partial class MainWindow : Window
	{
		Words words;
		int index_current = -1;
		bool caps = false;
		bool shift = false;
		DateTime antispam;
		TimeSpan spawn;
		static Random random;
		bool starts = false;
		

		static MainWindow()
		{
			random = new Random();


		}
		public MainWindow()
		{

			InitializeComponent();		
			words = new Words();		
			this.DataContext = words;	
			cmbthemes.SelectionChanged += Cmbthemes_SelectionChanged;
			

		}

		private void Cmbthemes_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			int index = cmbthemes.SelectedIndex;
			if (index == 0)
			{
				//как всем кнопкам установить динамик шаблон? через кнопка. Template={DynamicTemplate name} не получилось, писало ресурс не найден
				ControlTemplate tmpl;
				tmpl = (ControlTemplate)this.FindResource("standard");
				ChangeTemplate(tmpl);
			}
			else
			{
				ControlTemplate tmpl;

				tmpl = (ControlTemplate)this.FindResource("modify");
				ChangeTemplate(tmpl);
			}
			txbText.Focus();
		}


		/// <summary>
		/// меняю шаблон кнопки
		/// </summary>
		/// <param name="templ"></param>
		void ChangeTemplate(ControlTemplate templ)
		{
			foreach (UIElement item in grid_row2.Children)
			{
				if (item is Button)
				{
					Button s = item as Button;
					s.Template = templ;
				}

			}

			foreach (UIElement item in grid_row3.Children)
			{
				if (item is Button)
				{
					Button s = item as Button;
					s.Template = templ;
				}

			}
			foreach (UIElement item in grid_buttons.Children)
			{
				if (item is Button)
				{
					Button s = item as Button;
					s.Template = templ;
				}

			}
			foreach (UIElement item in grid_row4.Children)
			{
				if (item is Button)
				{
					Button s = item as Button;
					s.Template = templ;
				}

			}
			
		}


		private void slider_dif_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{

			txbval.Text = Convert.ToInt32(e.NewValue).ToString();
		}


		/// <summary>
		/// ALL LETTERS UP WHEN PUSHED SHIFT OR CAPS
		/// </summary>
		void UpAllLAters(bool dawn = false)
		{
			if (dawn)
			{
				foreach (UIElement item in grid_row2.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;
						string s1 = s.Content.ToString();
						(item as Button).Content = s1.ToLower();
					}

				}

				foreach (UIElement item in grid_row3.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;
						string s1 = s.Content.ToString();
						(item as Button).Content = s1.ToLower();
					}

				}
				foreach (UIElement item in grid_buttons.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;
						string s1 = s.Content.ToString();
						(item as Button).Content = s1.ToLower();
					}

				}
			}
			else
			{
				foreach (UIElement item in grid_row2.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;
						string s1 = s.Content.ToString();
						(item as Button).Content = s1.ToUpper();
					}

				}

				foreach (UIElement item in grid_row3.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;
						string s1 = s.Content.ToString();
						(item as Button).Content = s1.ToUpper();
					}

				}
				foreach (UIElement item in grid_buttons.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;
						string s1 = s.Content.ToString();
						(item as Button).Content = s1.ToUpper();
					}

				}
			}

		}




		/// <summary>
		/// считываю нажатые символы на клавиатуре + создание ивент нажатия по кнопкам
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void FrameworkElement_KeyUp(object sender, KeyEventArgs e)
		{
			if (!starts) return;

			bool back = false;
			bool tab = false;
			//System.Windows.Forms.MessageBox.Show(e.Key.ToString());
			bool find = false;
			int current_count = words.Last_char.Length;

			if ((e.Key == Key.RightShift || e.Key == Key.LeftShift) && !caps)
			{
				shift = false;
				UpAllLAters(true);
				btn_caps.IsEnabled = true;
			}

			if (current_count != words.Last_char.Length) find = true;
			if (!find) foreach (UIElement item in grid_buttons.Children)
				{
					if (item is Button)
					{
						Button s = item as Button;

						switch (e.Key)
						{

							case Key.D0:
							case Key.NumPad0:
								if (s.Name == "btn_0")
								{
									words.Last_char += "0";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D1:
							case Key.NumPad1:
								if (s.Name == "btn_1")
								{
									words.Last_char += "1";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D2:
							case Key.NumPad2:
								if (s.Name == "btn_2")
								{
									words.Last_char += "2";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D3:
							case Key.NumPad3:
								if (s.Name == "btn_3")
								{
									words.Last_char += "3";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D4:
							case Key.NumPad4:
								if (s.Name == "btn_4")
								{
									words.Last_char += "4";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D5:
							case Key.NumPad5:
								if (s.Name == "btn_5")
								{
									words.Last_char += "5";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D6:
							case Key.NumPad6:
								if (s.Name == "btn_6")
								{
									words.Last_char += "6";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D7:
							case Key.NumPad7:
								if (s.Name == "btn_7")
								{
									words.Last_char += "7";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D8:
							case Key.NumPad8:
								if (s.Name == "btn_8")
								{
									words.Last_char += "8";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D9:
							case Key.NumPad9:
								if (s.Name == "btn_9")
								{
									words.Last_char += "9";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.Subtract:
							case Key.OemMinus:
								if (s.Name == "subtract")
								{
									words.Last_char += "-";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.Back:
								if (s.Name == "btn_backspace" && words.Last_char.Length > 0)
								{
									words.Last_char = words.Last_char.Remove(words.Last_char.Length - 1);
									index_current -= 2;
									back = true;
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;

							case Key.Oem3:
								if (s.Name == "btn_st")
								{
									words.Last_char += "`";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;

							case Key.OemPlus:
								if (shift && Name == "btn_equals")
								{
									words.Last_char += "+";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								else
								{
									if (s.Content.ToString() == "=")
									{
										words.Last_char += "=";
										s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
									}
								}
								break;
							case Key.A:
								if (s.Name == "btn_a")
								{
									if (shift || caps)
									{
										words.Last_char += "A";
									}
									else
										words.Last_char += "a";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.S:
								if (s.Name == "btn_s")
								{
									if (shift || caps)
									{
										words.Last_char += "S";
									}
									else
										words.Last_char += "s";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.D:
								if (s.Name == "btn_d")
								{
									if (shift || caps)
									{
										words.Last_char += "D";
									}
									else
										words.Last_char += "d";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.F:
								if (s.Name == "btn_f")
								{
									if (shift || caps)
									{
										words.Last_char += "F";
									}
									else
										words.Last_char += "f";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.G:
								if (s.Name == "btn_g")
								{
									if (shift || caps)
									{
										words.Last_char += "G";
									}
									else
										words.Last_char += "g";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.H:
								if (s.Name == "btn_h")
								{
									if (shift || caps)
									{
										words.Last_char += "H";
									}
									else
										words.Last_char += "h";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.J:
								if (s.Name == "btn_j")
								{
									if (shift || caps)
									{
										words.Last_char += "J";
									}
									else
										words.Last_char += "j";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.K:
								if (s.Name == "btn_k")
								{
									if (shift || caps)
									{
										words.Last_char += "K";
									}
									else
										words.Last_char += "k";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.L:
								if (s.Name == "btn_l")
								{
									if (shift || caps)
									{
										words.Last_char += "L";
									}
									else
										words.Last_char += "l";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.Enter:
								if (s.Name == "btn_enter")
								{
									words.Last_char += " ";
									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.Oem1:
								if (s.Name == "btn_t4chk")
								{

									words.Last_char += ";";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
							case Key.OemQuotes:
								if (s.Name == "btn_ht4k")
								{

									words.Last_char += "'";

									s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

								}
								break;
						}


					}
				}
			if (current_count != words.Last_char.Length) find = true;
			if (!find) foreach (UIElement item in grid_row2.Children)
				{
					Button s = item as Button;
					switch (e.Key)
					{


						case Key.Tab:
							if (s.Name == "btn_Tab")
							{
								tab = true;
								words.Last_char += "   ";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.Q:
							if (s.Name == "btn_q")
							{
								if (shift || caps)
								{
									words.Last_char += "Q";
								}
								else
									words.Last_char += "q";

								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.E:
							if (s.Name == "btn_e")
							{
								if (shift || caps)
								{
									words.Last_char += "E";
								}
								else
									words.Last_char += "e";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.R:
							if (s.Name == "btn_r")
							{
								if (shift || caps)
								{
									words.Last_char += "R";
								}
								else
									words.Last_char += "r";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.T:
							if (s.Name == "btn_t")
							{
								if (shift || caps)
								{
									words.Last_char += "T";
								}
								else
									words.Last_char += "t";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.Y:
							if (s.Name == "btn_y")
							{
								if (shift || caps)
								{
									words.Last_char += "Y";
								}
								else
									words.Last_char += "y";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.U:
							if (s.Name == "btn_u")
							{
								if (shift || caps)
								{
									words.Last_char += "U";
								}
								else
									words.Last_char += "u";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.I:
							if (s.Name == "btn_i")
							{
								if (shift || caps)
								{
									words.Last_char += "I";
								}
								else
									words.Last_char += "i";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.O:
							if (s.Name == "btn_o")
							{
								if (shift || caps)
								{
									words.Last_char += "O";
								}
								else
									words.Last_char += "o";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.P:
							if (s.Name == "btn_p")
							{
								if (shift || caps)
								{
									words.Last_char += "P";
								}
								else
									words.Last_char += "p";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.W:
							if (s.Name == "btn_w")
							{
								if (shift || caps)
								{
									words.Last_char += "W";
								}
								else
									words.Last_char += "w";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.Oem5:
							if (s.Name == "btn_slashright")
							{
								words.Last_char += @"\";

								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
							}
							break;
						case Key.Oem6:
							if (s.Name == "btn_skobe_left")
							{
								words.Last_char += "]";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.OemOpenBrackets:
							if (s.Name == "btn_skobe_right")
							{
								words.Last_char += "[";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
					}
				}
			if (current_count != words.Last_char.Length) find = true;
			if (!find) foreach (UIElement item in grid_row3.Children)
				{
					Button s = item as Button;
					switch (e.Key)
					{


						case Key.Z:
							if (s.Name == "btn_z")
							{
								if (shift || caps)
								{
									words.Last_char += "Z";
								}
								else
									words.Last_char += "z";

								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.X:
							if (s.Name == "btn_x")
							{
								if (shift || caps)
								{
									words.Last_char += "X";
								}
								else
									words.Last_char += "x";

								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.C:
							if (s.Name == "btn_c")
							{
								if (shift || caps)
								{
									words.Last_char += "C";
								}
								else
									words.Last_char += "c";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.V:
							if (s.Name == "btn_v")
							{
								if (shift || caps)
								{
									words.Last_char += "V";
								}
								else
									words.Last_char += "v";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;

						case Key.B:
							if (s.Name == "btn_b")
							{
								if (shift || caps)
								{
									words.Last_char += "B";
								}
								else
									words.Last_char += "b";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.N:
							if (s.Name == "btn_n")
							{
								if (shift || caps)
								{
									words.Last_char += "N";
								}
								else
									words.Last_char += "n";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.M:
							if (s.Name == "btn_m")
							{
								if (shift || caps)
								{
									words.Last_char += "M";
								}
								else
									words.Last_char += "m";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.OemComma:
							if (s.Name == "btn_coma")
							{

								words.Last_char += ",";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;

						case Key.OemPeriod:
							if (s.Name == "btn_t4ck")
							{

								words.Last_char += ".";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.OemQuestion:
							if (s.Name == "btn_slashleft")
							{

								words.Last_char += "/";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;








					}


				}
			if (current_count != words.Last_char.Length) find = true;
			if (!find) foreach (UIElement item in grid_row4.Children)
				{
					Button s = item as Button;
					switch (e.Key)
					{
						case Key.Space:
							if (s.Name == "btn_space")
							{

								words.Last_char += " ";

								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.System:
							if (s.Content.ToString() == "Alt")
							{

								words.Last_char += " ";

								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.LWin:
							if (s.Name == "btn_win")
							{

								words.Last_char += " ";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.RWin:
							if (s.Name == "btn_win2")
							{

								words.Last_char += " ";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.LeftCtrl:

							if (s.Name == "btn_ctrl")
							{

								words.Last_char += " ";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
						case Key.RightCtrl:
							if (s.Name == "btn_ctrl2")
							{
								words.Last_char += " ";
								s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

							}
							break;
					}


				}
			if (current_count != words.Last_char.Length) find = true;

			if (find)
			{

				index_current++;
				if (tab) index_current += 2;
				AnalyzeWords(back);
			}
		}



		/// <summary>
		/// анализ вводимых символов и формирования нового предложения
		/// </summary>
		/// <param name="back"></param>
		void AnalyzeWords(bool back)
		{
			try
			{
				if (words.Last_char.Length == 0)
				{
					txbText.SelectionBrush = new SolidColorBrush(Colors.DarkCyan);
					txbText.Select(index_current + 1, 1);
					return;
				}
				if (index_current + 1 == txbText.Text.Length || index_current + 1 > txbText.Text.Length)
				{
					index_current = -1;
					SelectNewRords();
					words.Last_char = string.Empty;
					return;
				}
				txbText.SelectionBrush = new SolidColorBrush(Colors.DarkCyan);
				txbText.Select(index_current + 1, 1);

				if (index_current == -1) index_current = 0;
				if (!txbText.IsFocused) txbText.Focus();
				if (back) return;

				string temp1 = words.Last_char.Last().ToString();
				string temp2 = txbText.Text[index_current].ToString();

				if (chkbox_sensitive.IsChecked == false)
				{
					temp1 = temp1.ToLower();
					temp2 = temp2.ToLower();
				}

				if (temp1 != temp2)
				{

					words.Errors += 1;
				}
				else
				{
					words.Correct += 1;
				}

				if (words.Last_char.Length > 70) words.Last_char = string.Empty;
			}
			catch (Exception ex)
			{
				System.Windows.Forms.MessageBox.Show(ex.Message + ex.StackTrace);
			}
		}




		/// <summary>
		/// обработка шифта и капса
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		/// /// 	
		private void mainwnd_KeyDown(object sender, KeyEventArgs e)
		{
			if (!starts) return;
		
			if (e.Key == Key.LeftShift && !shift && !caps)
			{
				shift = true;
				btn_shift.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
				btn_caps.IsEnabled = false;

			}
			else
			if (e.Key == Key.RightShift && !shift && !caps)
			{
				shift = true;
				btn_shift2.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
				btn_caps.IsEnabled = false;

			}
			if (e.Key == Key.CapsLock && !shift)
			{
				if (!caps)
				{
					caps = true;
					btn_caps.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
					btn_shift.IsEnabled = false;
					btn_shift2.IsEnabled = false;
					shift = false;
					antispam = DateTime.Now;
				}
				else
				{
					spawn = DateTime.Now - antispam;
					antispam = DateTime.Now;
					if (spawn.TotalSeconds < 0.4) return;
					caps = false;
					btn_shift.IsEnabled = true;
					btn_shift2.IsEnabled = true;
					UpAllLAters(true);
					return;
				}
			}

			if (shift || (caps))
			{
				UpAllLAters();

			}

		}


		/// <summary>
		/// METHOD THAT SELECT NEXT SENTENces
		/// </summary>
		void SelectNewRords()
		{
			int a = (int)slider_dif.Value;
			switch (a)
			{
				case 1:
					txbText.Text = words.Difficulty_1[random.Next(0, words.Difficulty_1.Count)];
					break;
				case 2:
					txbText.Text = words.Difficulty_2[random.Next(0, words.Difficulty_2.Count)];
					break;
				case 3:
					txbText.Text = words.Difficulty_2[random.Next(0, words.Difficulty_2.Count)];
					char[] h = txbText.Text.ToCharArray();
					Array.Reverse(h);
					txbText.Text = new string(h);
					break;

			}
		}
		private void btn_start_Click(object sender, RoutedEventArgs e)
		{
		
			words.Correct = 0;
			starts = true;
			words.Errors = 0;
			words.Start = DateTime.Now;
			words.Last_char = "";
			words.Errors = 0;
			index_current = -1;
			words.Timer.Enabled = true;
			btn_start.IsEnabled = false;
			btn_stop.IsEnabled = true;
			chkbox_sensitive.IsEnabled = false;
			slider_dif.IsEnabled = false;

			SelectNewRords();
		}



		private void btn_stop_Click(object sender, RoutedEventArgs e)
		{
			words.Timer.Stop();

			slider_dif.IsEnabled = true;
			btn_stop.IsEnabled = false;
			btn_start.IsEnabled = true;
			starts = false;
			chkbox_sensitive.IsEnabled = true;

		}


	}
}
