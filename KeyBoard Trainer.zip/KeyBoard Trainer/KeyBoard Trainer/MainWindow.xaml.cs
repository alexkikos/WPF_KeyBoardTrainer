﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace KeyBoard_Trainer
{


    public partial class MainWindow : Window
    {
        bool ctrl = false;
        DlgBoxWindow dlgBox; 
        StatisticsWindow statisticsWindow;
        UsersInfo tmpuser = null;
        int index_current = -1;
        bool caps = false;
        bool shift = false;
        DateTime antispam;
        TimeSpan spawn;
        static Random random;
        bool starts = false;


        static MainWindow()
        {
            random = new Random();


        }
        public MainWindow()
        {

            InitializeComponent();
     
            this.DataContext = tmpuser.Words;
            tmpuser.Words = DataContext as Words;
            cmbthemes.SelectionChanged += Cmbthemes_SelectionChanged;
            cmbthemes.DataContext = tmpuser.Words;
            cmbthemes.SelectedIndex = 1;
        }

        public MainWindow(UsersInfo user)
        {
            tmpuser = user;
            InitializeComponent();            
            this.DataContext = tmpuser.Words;
            cmbthemes.SelectionChanged += Cmbthemes_SelectionChanged;
            cmbthemes.DataContext = tmpuser.Words;
            cmbthemes.SelectedIndex = tmpuser.My_themes;
            btn_lang.Content = tmpuser.Langues;
            ChangeLangues();

        }





        private void Cmbthemes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = cmbthemes.SelectedIndex;
            if (index == 0)
            {
                //как всем кнопкам установить динамик шаблон? через кнопка. Template={DynamicTemplate name} не получилось, писало ресурс не найден
                ControlTemplate tmpl;
                tmpl = (ControlTemplate)this.FindResource("standard");
                ChangeTemplate(tmpl);
            }
            else
            {
                ControlTemplate tmpl;

                tmpl = (ControlTemplate)this.FindResource("modify");
                ChangeTemplate(tmpl);
            }
            if (tmpuser != null) tmpuser.My_themes = cmbthemes.SelectedIndex;
            txbText.Focus();
        }


        /// <summary>
        /// меняю шаблон кнопки
        /// </summary>
        /// <param name="templ"></param>
        void ChangeTemplate(ControlTemplate templ)
        {
            foreach (UIElement item in grid_row2.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    s.Template = templ;
                }

            }

            foreach (UIElement item in grid_row3.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    s.Template = templ;
                }

            }
            foreach (UIElement item in grid_buttons.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    s.Template = templ;
                }

            }
            foreach (UIElement item in grid_row4.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    s.Template = templ;
                }

            }

        }


        private void slider_dif_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

            txbval.Text = Convert.ToInt32(e.NewValue).ToString();
        }


        /// <summary>
        /// ALL LETTERS UP WHEN PUSHED SHIFT OR CAPS
        /// </summary>
        void UpAllLAters(bool dawn = false)
        {
            if (dawn)
            {
                foreach (UIElement item in grid_row2.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;
                        string s1 = s.Content.ToString();
                        (item as Button).Content = s1.ToLower();
                    }

                }

                foreach (UIElement item in grid_row3.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;
                        string s1 = s.Content.ToString();
                        (item as Button).Content = s1.ToLower();
                    }

                }
                foreach (UIElement item in grid_buttons.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;
                        string s1 = s.Content.ToString();
                        (item as Button).Content = s1.ToLower();
                    }

                }
            }
            else
            {
                foreach (UIElement item in grid_row2.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;
                        string s1 = s.Content.ToString();
                        (item as Button).Content = s1.ToUpper();
                    }

                }

                foreach (UIElement item in grid_row3.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;
                        string s1 = s.Content.ToString();
                        (item as Button).Content = s1.ToUpper();
                    }

                }
                foreach (UIElement item in grid_buttons.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;
                        string s1 = s.Content.ToString();
                        (item as Button).Content = s1.ToUpper();
                    }

                }
            }

        }



        /// <summary>
        /// changes langues from to
        /// </summary>
        void ChangeLangues()
        {
            foreach (UIElement item in grid_row2.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    RecheckNameButton(s);
                }

            }

            foreach (UIElement item in grid_row3.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    RecheckNameButton(s);
                }

            }
            foreach (UIElement item in grid_buttons.Children)
            {
                if (item is Button)
                {
                    Button s = item as Button;
                    RecheckNameButton(s);
                }

            }

        }


        /// <summary>
        /// сhange all letters to ru/en
        /// </summary>
        /// <param name="button"></param>
        void RecheckNameButton(Button button)
        {
            if (caps) button.Content = button.Content.ToString().ToLower();
            if (tmpuser.Langues == "Ru")
            {
                switch (button.Content)
                {
                    case "q":
                        button.Content = "й";
                        break;
                    case "w":
                        button.Content = "ц";
                        break;
                    case "e":
                        button.Content = "у";
                        break;
                    case "r":
                        button.Content = "к";
                        break;
                    case "t":
                        button.Content = "е";
                        break;
                    case "y":
                        button.Content = "н";
                        break;
                    case "u":
                        button.Content = "г";
                        break;
                    case "i":
                        button.Content = "ш";
                        break;
                    case "o":
                        button.Content = "щ";
                        break;
                    case "p":
                        button.Content = "з";
                        break;
                    case "[":
                        button.Content = "х";
                        break;
                    case "]":
                        button.Content = "ъ";
                        break;
                    case "a":
                        button.Content = "ф";
                        break;
                    case "s":
                        button.Content = "ы";
                        break;
                    case "d":
                        button.Content = "в";
                        break;
                    case "f":
                        button.Content = "а";
                        break;
                    case "g":
                        button.Content = "п";
                        break;
                    case "h":
                        button.Content = "р";
                        break;
                    case "j":
                        button.Content = "о";
                        break;
                    case "k":
                        button.Content = "л";
                        break;
                    case "l":
                        button.Content = "д";
                        break;
                    case ";":
                        button.Content = "ж";
                        break;
                    case "'":
                        button.Content = "э";
                        break;
                    case "z":
                        button.Content = "я";
                        break;
                    case "x":
                        button.Content = "ч";
                        break;
                    case "c":
                        button.Content = "с";
                        break;
                    case "v":
                        button.Content = "м";
                        break;
                    case "b":
                        button.Content = "и";
                        break;
                    case "n":
                        button.Content = "т";
                        break;
                    case "m":
                        button.Content = "ь";
                        break;
                    case ",":
                        button.Content = "б";
                        break;
                    case ".":
                        button.Content = "ю";
                        break;
                    case "/":
                        button.Content = ".";
                        break;

                }
            }
            else
            {
                switch (button.Content)
                {
                    case "й":
                        button.Content = "q";
                        break;
                    case "ц":
                        button.Content = "w";
                        break;
                    case "у":
                        button.Content = "e";
                        break;
                    case "к":
                        button.Content = "r";
                        break;
                    case "е":
                        button.Content = "t";
                        break;
                    case "н":
                        button.Content = "y";
                        break;
                    case "г":
                        button.Content = "u";
                        break;
                    case "ш":
                        button.Content = "i";
                        break;
                    case "щ":
                        button.Content = "o";
                        break;
                    case "з":
                        button.Content = "p";
                        break;
                    case "х":
                        button.Content = "[";
                        break;
                    case "ъ":
                        button.Content = "]";
                        break;
                    case "ф":
                        button.Content = "a";
                        break;
                    case "ы":
                        button.Content = "s";
                        break;
                    case "в":
                        button.Content = "d";
                        break;
                    case "а":
                        button.Content = "f";
                        break;
                    case "п":
                        button.Content = "g";
                        break;
                    case "р":
                        button.Content = "h";
                        break;
                    case "о":
                        button.Content = "j";
                        break;
                    case "л":
                        button.Content = "k";
                        break;
                    case "д":
                        button.Content = "l";
                        break;
                    case "ж":
                        button.Content = ";";
                        break;
                    case "э":
                        button.Content = "'";
                        break;
                    case "я":
                        button.Content = "z";
                        break;
                    case "ч":
                        button.Content = "x";
                        break;
                    case "с":
                        button.Content = "c";
                        break;
                    case "м":
                        button.Content = "v";
                        break;
                    case "и":
                        button.Content = "b";
                        break;
                    case "т":
                        button.Content = "n";
                        break;
                    case "ь":
                        button.Content = "m";
                        break;
                    case "б":
                        button.Content = ",";
                        break;
                    case "ю":
                        button.Content = ".";
                        break;
                    case ".":
                        button.Content = "/";
                        break;

                }
            }
            if (caps) button.Content = button.Content.ToString().ToUpper();
        }





        /// <summary>
        /// считываю нажатые символы на клавиатуре + создание ивент нажатия по кнопкам
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrameworkElement_KeyUp(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Escape) this.Close();
            if (!starts) return;
            if (e.Key == Key.LeftCtrl && ctrl)
            {
                ctrl = false;
            }
            bool back = false;
            bool tab = false;
            //System.Windows.Forms.MessageBox.Show(e.Key.ToString());
            bool find = false;
            int current_count = tmpuser.Words.Last_char.Length;

            if ((e.Key == Key.RightShift || e.Key == Key.LeftShift) && !caps)
            {
                shift = false;
                UpAllLAters(true);
                btn_caps.IsEnabled = true;
            }

            if (current_count != tmpuser.Words.Last_char.Length) find = true;
            //block is ready
            if (!find) foreach (UIElement item in grid_buttons.Children)
                {
                    if (item is Button)
                    {
                        Button s = item as Button;

                        switch (e.Key)
                        {

                            case Key.D0:
                            case Key.NumPad0:
                                if (s.Name == "btn_0")
                                {
                                    tmpuser.Words.Last_char += "0";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D1:
                            case Key.NumPad1:
                                if (s.Name == "btn_1")
                                {
                                    tmpuser.Words.Last_char += "1";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D2:
                            case Key.NumPad2:
                                if (s.Name == "btn_2")
                                {
                                    tmpuser.Words.Last_char += "2";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D3:
                            case Key.NumPad3:
                                if (s.Name == "btn_3")
                                {
                                    tmpuser.Words.Last_char += "3";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D4:
                            case Key.NumPad4:
                                if (s.Name == "btn_4")
                                {
                                    tmpuser.Words.Last_char += "4";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D5:
                            case Key.NumPad5:
                                if (s.Name == "btn_5")
                                {
                                    tmpuser.Words.Last_char += "5";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D6:
                            case Key.NumPad6:
                                if (s.Name == "btn_6")
                                {
                                    tmpuser.Words.Last_char += "6";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D7:
                            case Key.NumPad7:
                                if (s.Name == "btn_7")
                                {
                                    tmpuser.Words.Last_char += "7";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D8:
                            case Key.NumPad8:
                                if (s.Name == "btn_8")
                                {
                                    tmpuser.Words.Last_char += "8";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D9:
                            case Key.NumPad9:
                                if (s.Name == "btn_9")
                                {
                                    tmpuser.Words.Last_char += "9";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.Subtract:
                            case Key.OemMinus:
                                if (s.Name == "subtract")
                                {
                                    tmpuser.Words.Last_char += "-";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.Back:
                                if (s.Name == "btn_backspace" && tmpuser.Words.Last_char.Length > 0)
                                {
                                    tmpuser.Words.Last_char = tmpuser.Words.Last_char.Remove(tmpuser.Words.Last_char.Length - 1);
                                    index_current -= 2;
                                    back = true;
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;

                            case Key.Oem3:
                                if (s.Name == "btn_st")
                                {
                                    tmpuser.Words.Last_char += "`";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;

                            case Key.OemPlus:
                                if (shift && Name == "btn_equals")
                                {
                                    tmpuser.Words.Last_char += "+";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                else
                                {
                                    if (s.Content.ToString() == "=")
                                    {
                                        tmpuser.Words.Last_char += "=";
                                        s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                                    }
                                }
                                break;
                            case Key.A:
                                if (s.Name == "btn_a")
                                {
                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "A";
                                        else
                                            tmpuser.Words.Last_char += "Ф";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "a";
                                        else
                                            tmpuser.Words.Last_char += "ф";

                                    }

                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.S:
                                if (s.Name == "btn_s")
                                {


                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "S";
                                        else
                                            tmpuser.Words.Last_char += "Ы";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "s";
                                        else
                                            tmpuser.Words.Last_char += "ы";

                                    }

                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.D:
                                if (s.Name == "btn_d")
                                {
                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "D";
                                        else
                                            tmpuser.Words.Last_char += "В";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "d";
                                        else
                                            tmpuser.Words.Last_char += "в";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.F:
                                if (s.Name == "btn_f")
                                {


                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "F";
                                        else
                                            tmpuser.Words.Last_char += "А";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "f";
                                        else
                                            tmpuser.Words.Last_char += "а";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.G:
                                if (s.Name == "btn_g")
                                {

                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "G";
                                        else
                                            tmpuser.Words.Last_char += "П";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "G";
                                        else
                                            tmpuser.Words.Last_char += "п";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.H:
                                if (s.Name == "btn_h")
                                {

                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "H";
                                        else
                                            tmpuser.Words.Last_char += "Р";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "h";
                                        else
                                            tmpuser.Words.Last_char += "р";

                                    }



                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.J:
                                if (s.Name == "btn_j")
                                {

                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "J";
                                        else
                                            tmpuser.Words.Last_char += "О";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "j";
                                        else
                                            tmpuser.Words.Last_char += "о";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.K:
                                if (s.Name == "btn_k")
                                {

                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "K";
                                        else
                                            tmpuser.Words.Last_char += "Л";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "k";
                                        else
                                            tmpuser.Words.Last_char += "л";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.L:
                                if (s.Name == "btn_l")
                                {


                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "L";
                                        else
                                            tmpuser.Words.Last_char += "Д";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "l";
                                        else
                                            tmpuser.Words.Last_char += "д";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.Enter:
                                if (s.Name == "btn_enter")
                                {
                                    tmpuser.Words.Last_char += " ";
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.Oem1:
                                if (s.Name == "btn_t4chk")
                                {

                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += ";";
                                        else
                                            tmpuser.Words.Last_char += "Ж";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += ";";
                                        else
                                            tmpuser.Words.Last_char += "ж";

                                    }

                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                            case Key.OemQuotes:
                                if (s.Name == "btn_ht4k")
                                {

                                    if (shift || caps)
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "'";
                                        else tmpuser.Words.Last_char += "Э";
                                    }
                                    else
                                    {
                                        if (tmpuser.Langues == "En")
                                            tmpuser.Words.Last_char += "'";
                                        else
                                            tmpuser.Words.Last_char += "э";

                                    }
                                    s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                                }
                                break;
                        }


                    }
                }
            if (current_count != tmpuser.Words.Last_char.Length) find = true;
            //block is ready
            if (!find) foreach (UIElement item in grid_row2.Children)
                {
                    Button s = item as Button;
                    switch (e.Key)
                    {


                        case Key.Tab:
                            if (s.Name == "btn_Tab")
                            {
                                tab = true;
                                tmpuser.Words.Last_char += "   ";
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.Q:
                            if (s.Name == "btn_q")
                            {


                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "Q";
                                    else
                                        tmpuser.Words.Last_char += "й";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "q";
                                    else
                                        tmpuser.Words.Last_char += "й";

                                }


                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.E:
                            if (s.Name == "btn_e")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "E";
                                    else
                                        tmpuser.Words.Last_char += "у";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "e";
                                    else
                                        tmpuser.Words.Last_char += "у";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.R:
                            if (s.Name == "btn_r")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "r";
                                    else
                                        tmpuser.Words.Last_char += "К";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "r";
                                    else
                                        tmpuser.Words.Last_char += "к";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.T:
                            if (s.Name == "btn_t")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "T";
                                    else
                                        tmpuser.Words.Last_char += "Е";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "t";
                                    else
                                        tmpuser.Words.Last_char += "е";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.Y:
                            if (s.Name == "btn_y")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "Y";
                                    else
                                        tmpuser.Words.Last_char += "Н";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "y";
                                    else
                                        tmpuser.Words.Last_char += "н";

                                }


                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.U:
                            if (s.Name == "btn_u")
                            {


                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "U";
                                    else
                                        tmpuser.Words.Last_char += "Г";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "u";
                                    else
                                        tmpuser.Words.Last_char += "г";

                                }


                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.I:
                            if (s.Name == "btn_i")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "I";
                                    else
                                        tmpuser.Words.Last_char += "Ш";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "i";
                                    else
                                        tmpuser.Words.Last_char += "ш";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.O:
                            if (s.Name == "btn_o")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "O";
                                    else
                                        tmpuser.Words.Last_char += "Щ";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "o";
                                    else
                                        tmpuser.Words.Last_char += "щ";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.P:
                            if (s.Name == "btn_p")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "P";
                                    else
                                        tmpuser.Words.Last_char += "З";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "p";
                                    else
                                        tmpuser.Words.Last_char += "з";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.W:
                            if (s.Name == "btn_w")
                            {


                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "W";
                                    else
                                        tmpuser.Words.Last_char += "Ц";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "w";
                                    else
                                        tmpuser.Words.Last_char += "ц";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.Oem5:
                            if (s.Name == "btn_slashright")
                            {
                                tmpuser.Words.Last_char += @"\";

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                            }
                            break;
                        case Key.Oem6:
                            if (s.Name == "btn_skobe_left")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "]";
                                    else
                                        tmpuser.Words.Last_char += "Ъ";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "]";
                                    else
                                        tmpuser.Words.Last_char += "ъ";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.OemOpenBrackets:
                            if (s.Name == "btn_skobe_right")
                            {


                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "[";
                                    else
                                        tmpuser.Words.Last_char += "Х";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "[";
                                    else
                                        tmpuser.Words.Last_char += "х";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                    }
                }
            if (current_count != tmpuser.Words.Last_char.Length) find = true;
            //block is ready
            if (!find) foreach (UIElement item in grid_row3.Children)
                {
                    Button s = item as Button;
                    switch (e.Key)
                    {


                        case Key.Z:
                            if (s.Name == "btn_z")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "Z";
                                    else
                                        tmpuser.Words.Last_char += "Я";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "z";
                                    else
                                        tmpuser.Words.Last_char += "я";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.X:
                            if (s.Name == "btn_x")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "X";
                                    else
                                        tmpuser.Words.Last_char += "ч";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "x";
                                    else
                                        tmpuser.Words.Last_char += "ч";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.C:
                            if (s.Name == "btn_c")
                            {


                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "C";
                                    else
                                        tmpuser.Words.Last_char += "с";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "c";
                                    else
                                        tmpuser.Words.Last_char += "с";

                                }



                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.V:
                            if (s.Name == "btn_v")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "V";
                                    else
                                        tmpuser.Words.Last_char += "М";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "v";
                                    else
                                        tmpuser.Words.Last_char += "м";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;

                        case Key.B:
                            if (s.Name == "btn_b")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "B";
                                    else
                                        tmpuser.Words.Last_char += "И";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "b";
                                    else
                                        tmpuser.Words.Last_char += "и";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.N:
                            if (s.Name == "btn_n")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "N";
                                    else
                                        tmpuser.Words.Last_char += "Т";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "n";
                                    else
                                        tmpuser.Words.Last_char += "т";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.M:
                            if (s.Name == "btn_m")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "M";
                                    else
                                        tmpuser.Words.Last_char += "ь";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "m";
                                    else
                                        tmpuser.Words.Last_char += "ь";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.OemComma:
                            if (s.Name == "btn_coma")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += ",";
                                    else
                                        tmpuser.Words.Last_char += "Б";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += ",";
                                    else
                                        tmpuser.Words.Last_char += "б";

                                }

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;

                        case Key.OemPeriod:
                            if (s.Name == "btn_t4ck")
                            {

                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += ".";
                                    else
                                        tmpuser.Words.Last_char += "Ю";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += ".";
                                    else
                                        tmpuser.Words.Last_char += "ю";

                                }
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.OemQuestion:
                            if (s.Name == "btn_slashleft")
                            {


                                if (shift || caps)
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "/";
                                    else
                                        tmpuser.Words.Last_char += ".";
                                }
                                else
                                {
                                    if (tmpuser.Langues == "En")
                                        tmpuser.Words.Last_char += "/";
                                    else
                                        tmpuser.Words.Last_char += ".";

                                }



                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;

                    }


                }
            if (current_count != tmpuser.Words.Last_char.Length) find = true;
            if (!find) foreach (UIElement item in grid_row4.Children)
                {
                    Button s = item as Button;
                    switch (e.Key)
                    {
                        case Key.Space:
                            if (s.Name == "btn_space")
                            {

                                tmpuser.Words.Last_char += " ";

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.System:
                            if (s.Content.ToString() == "Alt")
                            {

                                tmpuser.Words.Last_char += " ";

                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.LWin:
                            if (s.Name == "btn_win")
                            {

                                tmpuser.Words.Last_char += " ";
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.RWin:
                            if (s.Name == "btn_win2")
                            {

                                tmpuser.Words.Last_char += " ";
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.LeftCtrl:

                            if (s.Name == "btn_ctrl")
                            {

                                tmpuser.Words.Last_char += " ";
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                        case Key.RightCtrl:
                            if (s.Name == "btn_ctrl2")
                            {
                                tmpuser.Words.Last_char += " ";
                                s.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));

                            }
                            break;
                    }


                }
            if (current_count != tmpuser.Words.Last_char.Length) find = true;

            if (find)
            {

                index_current++;
                if (tab) index_current += 2;
                AnalyzeWords(back);
            }
        }



        /// <summary>
        /// анализ вводимых символов и формирования нового предложения
        /// </summary>
        /// <param name="back"></param>
        void AnalyzeWords(bool back)
        {
            try
            {
                if (tmpuser.Words.Last_char.Length == 0)
                {
                    txbText.SelectionBrush = new SolidColorBrush(Colors.DarkCyan);
                    txbText.Select(index_current + 1, 1);
                    return;
                }
                if (index_current + 1 == txbText.Text.Length || index_current + 1 > txbText.Text.Length)
                {
                    index_current = -1;
                    SelectNewRords();
                    tmpuser.Words.Last_char = string.Empty;
                    return;
                }
                txbText.SelectionBrush = new SolidColorBrush(Colors.DarkCyan);
                txbText.Select(index_current + 1, 1);

                if (index_current == -1) index_current = 0;
                if (!txbText.IsFocused) txbText.Focus();
                if (back) return;

                string temp1 = tmpuser.Words.Last_char.Last().ToString();
                string temp2 = txbText.Text[index_current].ToString();

                if (chkbox_sensitive.IsChecked == false)
                {
                    temp1 = temp1.ToLower();
                    temp2 = temp2.ToLower();
                }

                if (temp1 != temp2)
                {

                    tmpuser.Words.Errors += 1;
                }
                else
                {
                    tmpuser.Words.Correct += 1;
                }

                if (tmpuser.Words.Last_char.Length > 70) tmpuser.Words.Last_char = string.Empty;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }




        /// <summary>
        /// обработка шифта и капса
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// /// 	
        private void mainwnd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.LeftShift && ctrl)
            {

                if (tmpuser.Langues == "En")
                {
                    tmpuser.Langues = "Ru";
                    btn_lang.Content = "Ru";
                }
                else
                {
                    tmpuser.Langues = "En";
                    btn_lang.Content = "En";
                }
                ChangeLangues();
                return;
            }

            if (e.Key == Key.LeftCtrl)
            {
                ctrl = true;
            }
            if (!starts) return;
            if (e.Key == Key.LeftShift && !shift && !caps)
            {
                shift = true;
                btn_shift.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                btn_caps.IsEnabled = false;

            }
            else
            if (e.Key == Key.RightShift && !shift && !caps)
            {
                shift = true;
                btn_shift2.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                btn_caps.IsEnabled = false;

            }
            if (e.Key == Key.CapsLock && !shift)
            {
                if (!caps)
                {
                    caps = true;
                    btn_caps.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                    btn_shift.IsEnabled = false;
                    btn_shift2.IsEnabled = false;
                    shift = false;
                    antispam = DateTime.Now;
                }
                else
                {
                    spawn = DateTime.Now - antispam;
                    antispam = DateTime.Now;
                    if (spawn.TotalSeconds < 0.4) return;
                    caps = false;
                    btn_shift.IsEnabled = true;
                    btn_shift2.IsEnabled = true;
                    UpAllLAters(true);
                    return;
                }
            }

            if (shift || (caps))
            {
                UpAllLAters();

            }

        }


        /// <summary>
        /// METHOD THAT SELECT NEXT SENTENces
        /// </summary>
        void SelectNewRords()
        {
            int a = (int)slider_dif.Value;
            switch (a)
            {
                case 1:
                    txbText.Text = tmpuser.Words.Difficulty_1[random.Next(0, tmpuser.Words.Difficulty_1.Count)];
                    break;
                case 2:
                    txbText.Text = tmpuser.Words.Difficulty_2[random.Next(0, tmpuser.Words.Difficulty_2.Count)];
                    break;
                case 3:
                    txbText.Text = tmpuser.Words.Difficulty_2[random.Next(0, tmpuser.Words.Difficulty_2.Count)];
                    char[] h = txbText.Text.ToCharArray();
                    Array.Reverse(h);
                    txbText.Text = new string(h);
                    break;

            }
        }
        private void btn_start_Click(object sender, RoutedEventArgs e)
        {

            tmpuser.Words.Correct = 0;
            tmpuser.Words.IniFields();
            starts = true;          
            tmpuser.Words.Start = DateTime.Now;
            index_current = -1;
            tmpuser.Words.Timer.Enabled = true;
            btn_start.IsEnabled = false;
            btn_stop.IsEnabled = true;
            chkbox_sensitive.IsEnabled = false;
            slider_dif.IsEnabled = false;

            SelectNewRords();
        }



        private void btn_stop_Click(object sender, RoutedEventArgs e)
        {
            tmpuser.Words.Timer.Stop();

            slider_dif.IsEnabled = true;
            btn_stop.IsEnabled = false;
            btn_start.IsEnabled = true;
            starts = false;
            chkbox_sensitive.IsEnabled = true;
            if (tmpuser != null)
            {
                tmpuser.Statistics.Add(new Classes.Statistics(tmpuser.Words.TimeSpan, DateTime.Now, tmpuser.Words.Correct, tmpuser.Words.Errors, (int)slider_dif.Value, chkbox_sensitive.IsChecked == true ? true : false, tmpuser.Langues));
            }
        }

        private void mainwnd_Closing(object sender, CancelEventArgs e)
        {
            dlgBox = new DlgBoxWindow("You realy want to exit?");
            Button button = new Button();
            button.Content = "No";
            button.Style = dlgBox.btnok.Style;
            button.Click += Button_Click_Cancel_DlgBox;
            dlgBox.wrap.Children.Add(button);
            if (dlgBox.ShowDialog() != true)
            {
                e.Cancel = true;
            }
        }

        private void Button_Click_Cancel_DlgBox(object sender, RoutedEventArgs e)
        {
            if (dlgBox != null) dlgBox.Close();
        }

        private void btnstat_Click(object sender, RoutedEventArgs e)
        {
            
            statisticsWindow = new StatisticsWindow(tmpuser);
            statisticsWindow.ShowDialog();           
        }

        private void Cntx_ru_Click(object sender, RoutedEventArgs e)
        {
            
                cntx_en.IsChecked = false;
                cntx_ru.IsChecked = true;
                tmpuser.Langues = "Ru";
                btn_lang.Content = "Ru";
                ChangeLangues();

            
        }

        private void Cntx_en_Click(object sender, RoutedEventArgs e)
        {
           
                cntx_en.IsChecked = true;
                cntx_ru.IsChecked = false;
                tmpuser.Langues = "En";
                btn_lang.Content = "En";
                ChangeLangues();

            
        }

        private void ContextMenu_Loaded(object sender, RoutedEventArgs e)
        {

            if (tmpuser.Langues == "En")
            {
                
                Cntx_en_Click(null, null);
            }
            else
            {
                Cntx_ru_Click(null, null);

            }



        }
    }
}
